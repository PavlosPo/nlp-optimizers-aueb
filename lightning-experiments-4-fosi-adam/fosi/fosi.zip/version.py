"""
``fosi`` is a hybrid optimizer that integrates between first and second order optimizers.
"""

__version__ = '0.1'
